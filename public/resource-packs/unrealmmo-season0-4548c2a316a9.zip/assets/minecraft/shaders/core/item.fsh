#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec4 vertexColor;
in vec4 lightMapColor;
in vec4 overlayColor;
in vec2 texCoord0;

out vec4 fragColor;

in float ownerHeadMarker;
in vec3 ownerHeadViewPosition;
in vec2 ownerFaceUV;
flat in vec3 ownerP00;
flat in vec3 ownerP10;
flat in vec3 ownerP01;
flat in vec3 ownerEye;
flat in vec3 ownerTint;
flat in vec2 ownerAtlasBase;

void main() {
    vec4 color = texture(Sampler0, texCoord0);
    if (ownerHeadMarker > 0.5) {
        color=texture(Sampler0,(ownerAtlasBase+vec2(64.0)+ownerFaceUV*128.0)/vec2(textureSize(Sampler0,0)));
        vec2 dx=dFdx(ownerFaceUV),dy=dFdy(ownerFaceUV);
        vec3 px=dFdx(ownerHeadViewPosition),py=dFdy(ownerHeadViewPosition);
        float det=dx.x*dy.y-dx.y*dy.x;
        vec3 du=(px*dy.y-py*dx.y)/det;
        vec3 dv=(py*dx.x-px*dy.x)/det;
        vec3 u=ownerP10-ownerP00,v=ownerP01-ownerP00;
        vec3 local=ownerP00+u*ownerFaceUV.x+v*ownerFaceUV.y;
        vec3 delta=ownerEye-local;
        float scale=length(du)/length(u);
        vec3 eye=ownerHeadViewPosition
            +du/length(u)*dot(delta,normalize(u))
            +dv/length(v)*dot(delta,normalize(v))
            +normalize(cross(du,dv))*scale*dot(delta,normalize(cross(u,v)));
        // Whole-model eye-anchor classification, never per-fragment radius clipping.
        if(length(eye)<0.18) discard;
        color.a=1.0;
        color.rgb/=max(ownerTint,vec3(1.0/255.0));
    }
#ifdef ALPHA_CUTOUT
    if (color.a < ALPHA_CUTOUT) {
        discard;
    }
#endif

    color *= vertexColor * ColorModulator;
    color.rgb = mix(overlayColor.rgb, color.rgb, overlayColor.a);
    color *= lightMapColor;

    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}
