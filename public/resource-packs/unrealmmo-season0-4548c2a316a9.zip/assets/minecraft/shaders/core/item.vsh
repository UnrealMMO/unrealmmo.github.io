#version 330

#moj_import <minecraft:light.glsl>
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>
#moj_import <minecraft:sample_lightmap.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
in ivec2 UV1;
in ivec2 UV2;
in vec3 Normal;

uniform sampler2D Sampler0;
uniform sampler2D Sampler1;
uniform sampler2D Sampler2;

out float sphericalVertexDistance;
out float cylindricalVertexDistance;
out vec4 vertexColor;
out vec4 lightMapColor;
out vec4 overlayColor;

out vec2 texCoord0;

// Owner-only display tint; ordinary items retain the vanilla lighting path.
out float ownerHeadMarker;
out vec3 ownerHeadViewPosition;
out vec2 ownerFaceUV;
flat out vec3 ownerP00;
flat out vec3 ownerP10;
flat out vec3 ownerP01;
flat out vec3 ownerEye;
flat out vec3 ownerTint;
flat out vec2 ownerAtlasBase;

void main() {
    vec2 pixel = UV0 * vec2(textureSize(Sampler0,0));
    ivec2 cornerPixel=ivec2(floor(pixel));
    vec4 header=texelFetch(Sampler0,cornerPixel,0);
    int corner=int(round(header.a*255.0))-248;
    bool ownerHead=corner>=0 && corner<=3 && all(lessThan(abs(header.rgb-vec3(19,83,157)/255.0),vec3(.001)));
    ownerFaceUV=vec2(corner%2,corner/2);
    ownerAtlasBase=vec2(cornerPixel)-ownerFaceUV*255.0;
    int stepX=corner%2==0 ? 1 : -1;
    ownerP00=(texelFetch(Sampler0,cornerPixel+ivec2(stepX,0),0).rgb*255.0-64.0)/4.0;
    ownerP10=(texelFetch(Sampler0,cornerPixel+ivec2(2*stepX,0),0).rgb*255.0-64.0)/4.0;
    ownerP01=(texelFetch(Sampler0,cornerPixel+ivec2(3*stepX,0),0).rgb*255.0-64.0)/4.0;
    ownerEye=(Color.rgb*255.0-64.0)/2.0;
    ownerTint=Color.rgb;
    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    ownerHeadMarker = ownerHead ? 1.0 : 0.0;
    ownerHeadViewPosition = (ModelViewMat * vec4(Position,1.0)).xyz;

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = minecraft_mix_light(Light0_Direction, Light1_Direction, Normal, Color);
    lightMapColor = sample_lightmap(Sampler2, UV2);
    overlayColor = texelFetch(Sampler1, UV1, 0);

    texCoord0 = UV0;
}
